#!/usr/bin/env python
#
# SPDX-License-Identifier: MIT
import pylama.main
pylama.main.shell()
